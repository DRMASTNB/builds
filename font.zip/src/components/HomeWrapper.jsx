
import Main from "../views/Main1.jsx";

/**
 *
 * @returns {JSX.Element}
 * @constructor
 */
export const HomeWrapper = () => {
   
    // 查询参数已存在，渲染实际的 Main 组件
    return <Main/>;
};