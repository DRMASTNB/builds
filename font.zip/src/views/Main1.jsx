import React, { useEffect,  useState } from 'react';
import { Layout, Menu, Button, Badge, Space, Modal, Table } from "antd";
import { BellOutlined, UserOutlined,  AppstoreOutlined } from '@ant-design/icons';
import backgroundImage from '../assets/LoginBackground2.jpg';
import logo2 from "../assets/Dplogo.png";
import Scene3D from '../components/Scene3D.jsx'
const { Sider, Content } = Layout;

// 添加 LEVELS 常量定义
const LEVELS = ['campus', 'plot', 'building', 'floor', 'room'];

// 顶部导航菜单项
const topMenuItems = [
    {
        key: 'archive',
        label: <div style={{ width: '120px', textAlign: 'center' }}>
                 <p style={{ fontSize: "24px", margin: "10px", color: "white" }}>档案信息</p>
               </div>,
        children: [
            { key: 'archive-1', label: '地产信息' },
            { key: 'archive-2', label: '土地证' },
        ]
    },
    {
        key: 'function',
        label: <div style={{ width: '120px', textAlign: 'center' }}>
                 <p style={{ fontSize: "24px", margin: "10px", color: "white" }}>功能用途</p>
               </div>,
        children: [
            { key: 'function-1', label: '建筑合规使用性质' },
            { key: 'function-2', label: '现状功能描述' },
            { key: 'function-3', label: '稀缺功能区' },
            { key: 'function-4', label: '人防区域' },
            { key: 'function-5', label: '现状防火分区' },
        ]
    },

    {
        key: 'power',
        label: <div style={{ width: '120px', textAlign: 'center' }}>
                 <p style={{ fontSize: "24px", margin: "10px", color: "white" }}>配电信息</p>
               </div>,
        children: [
            { key: 'power-1', label: '1' },
            { key: 'power-2', label: '2' },
        ]
    },
    {
        key: 'construction',
        label: <div style={{ width: '120px', textAlign: 'center' }}>
                 <p style={{ fontSize: "24px", margin: "10px", color: "white" }}>建设信息</p>
               </div>,
        children: [
            { key: 'construction-1', label: '1' },
            { key: 'construction-2', label: '2' },
        ]
    },
    {
        key: 'maintenance',
        label: <div style={{ width: '120px', textAlign: 'center' }}>
                 <p style={{ fontSize: "24px", margin: "10px", color: "white" }}>运维信息</p>
               </div>,
        children: [
            { key: 'maintenance-1', label: '1' },
            { key: 'maintenance-2', label: '2' },
        ]
    },
];

// 左侧菜单项
const siderItems = [
    {
        key: 'campus',
        label: '校区',
        children: [
            { key: 'gulou', label: '鼓楼校区' },
            { key: 'xianlin', label: '仙林校区' },
        ]
    },
    {
        key: 'plot',
        label: '地块',
        icon: <AppstoreOutlined />,
        children: [
            { key: 'plot1', label: '蒙明伟楼地块' },
            { key: 'plot2', label: '图书馆地块' },
        ]
    },
    {
        key: 'building',
        label: '楼栋',
        icon: <AppstoreOutlined />,
        children: [
            { key: 'plot1', label: '蒙明伟楼' },
            { key: 'plot2', label: '楼二' },
        ]
    },
    {
        key: 'floor',
        label: '楼层',
        icon: <AppstoreOutlined />,
        children: [
            { key: 'plot1', label: '1F' },
            { key: 'plot2', label: '2F' },
        ]
    },
    {
        key: 'room',
        label: '房间',
        icon: <AppstoreOutlined />,
        children: [
            { key: 'plot1', label: '101' },
            { key: 'plot2', label: '102' },
        ]
    },
    // ... 其他菜单项保持不变
];

const Main1 = () => {
    const [currentLevel, setCurrentLevel] = useState('campus');
    const [modalVisible, setModalVisible] = useState(false);
    const [tableData, setTableData] = useState([]);
    const [tableColoum, setTableColoum] = useState([]);
    const [selectedItems, setSelectedItems] = useState({
        campus: 'gulou',
        plot: null,
        building: null,
        floor: null,
        room: null
    });

    // 处理菜单项选择
    const handleMenuSelect = ({ key }) => {
        const [level, value] = key.split('-');

        // 清除当前层级之后的所有选择
        const newSelectedItems = { ...selectedItems };
        const currentIndex = LEVELS.indexOf(level);
        LEVELS.forEach((lvl, index) => {
            if (index > currentIndex) {
                newSelectedItems[lvl] = null;
            }
        });

        setCurrentLevel(level);
        setSelectedItems({
            ...newSelectedItems,
            [level]: value
        });
    };

    // 更新获取菜单项样式的逻辑
    const getMenuItemStyle = (level) => {
        const currentIndex = LEVELS.indexOf(currentLevel);
        const itemIndex = LEVELS.indexOf(level);
        const isActive = itemIndex <= currentIndex;

        return {
            backgroundColor: isActive ? '#f0f0f0' : 'transparent',
            fontWeight: isActive ? 'bold' : 'normal'
        };
    };
    const data=[
        {
            key: '1',
            age:"蒙民伟楼",
            a:"南京大学科技楼二期",
            b:"2001~2003年",
            c:"2003/11/21",
            d:"科研与教学",
            e:"地上28层，地下2层"

        }
    ]
    const MenuItemClick = ({ key }) => {
        switch (key) {
            // 档案信息
            case 'archive-1':
                break;
            case 'archive-2':
                break;
            
            // 功能用途
            // 功能用途点到时，默认跳转对应的level层次，并高亮对应的分区
            case 'function-1':
                break;
            case 'function-2':
                break;
            // ... 其他功能用途子项

            // 配电信息
            case 'power-1':
            case 'power-2':
                break;

            // 建设信息
            case 'construction-1':
            case 'construction-2':
                break;

            // 运维信息
            case 'maintenance-1':
            case 'maintenance-2':
                break;

            default:
                break;

        }
    };
    const columns = [
        {
            title: '房屋',
            dataIndex: 'age',
            key: 'age',
        },
        {
            title: '南京大学科技楼二期',
            dataIndex: 'a',
            key: 'a',
        },
        {
            title: '项目建设时间',
            dataIndex: 'b',
            key: 'b',
        },
        {
            title: '项目竣工时间',
            dataIndex: 'c',
            key: 'c',
        },
        {
            title: '建筑用途',
            dataIndex: 'd',
            key: 'd',
        },
        {
            title: '层数',
            dataIndex: 'e',
            key: 'e',
        },
    ];

    // 添加处理层级变化的副作用
    useEffect(() => {
        const currentIndex = LEVELS.indexOf(currentLevel);
        const newSelectedItems = { ...selectedItems };

        // 清除当前层级之后的选择
        LEVELS.forEach((level, index) => {
            if (index > currentIndex) {
                newSelectedItems[level] = null;
            }
        });

        setSelectedItems(newSelectedItems);
    }, [currentLevel]);

    return (
        <Layout>
            {/* 顶部区域 */}
            <div style={{
                backgroundImage: `url(${backgroundImage})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                position: 'relative'

            }}>
                {/* 上部分：Logo和用户信息 */}
                <div style={{
                    height: '60px',
                    background: 'rgba(255, 255, 255, 0)',
                    backdropFilter: 'blur(8px)',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '0 24px',
                    borderBottom: '1px solid rgba(255, 255, 255, 1)'
                }}>
                    {/* 左侧Logo区域 */}
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px'
                    }}>
                        <img
                            src={logo2}
                            alt="南京大学"
                            style={{ height: '40px' }}
                        />
                        <span style={{
                            fontSize: '20px',
                            fontWeight: 'bold',
                            color: 'rgba(255, 255, 255, 1)'
                        }}>
                            南京大学空间数据资产平台
                        </span>
                    </div>

                    {/* 右侧用户信息区域 */}
                    <Space size={24}>
                        <Badge count={6}>
                            <Button
                                type="text"
                                icon={<BellOutlined />}
                                style={{ fontSize: '18px' }}
                            />
                        </Badge>
                        <Button
                            type="text"
                            icon={<UserOutlined />}
                            style={{ fontSize: '18px' }}
                        >
                            用户界面管理界面
                        </Button>
                    </Space>
                </div>

                {/* 下部分：导航菜单 */}
                <div style={{
                    height: '60px',
                    background: 'rgba(255, 255, 255, 0)',
                    backdropFilter: 'blur(8px)',
                }}>
                    <Menu
                        mode="horizontal"
                        items={topMenuItems}
                        style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            background: 'transparent',
                            borderBottom: 'true',
                            height: '60px',
                            lineHeight: '60px',
                            padding: '0 50px',
                        }}
                        onClick={MenuItemClick}
                    >

                    </Menu>
                </div>
            </div>

            {/* 主要内容区域 */}
            <Layout style={{ minHeight: 'calc(100vh - 120px)' }}>
                <Sider width={300} style={{ background: '#fff' }}>
                    <Menu
                        mode="inline"
                        onSelect={handleMenuSelect}
                        defaultOpenKeys={['campus']}
                        style={{ height: '100%' }}
                    >
                        {siderItems.map(item => (
                            <Menu.SubMenu
                                key={item.key}
                                title={item.label}
                                style={getMenuItemStyle(item.key)}
                            >
                                {item.children.map(child => (
                                    <Menu.Item
                                        key={`${item.key}-${child.key}`}
                                        style={getMenuItemStyle(item.key)}
                                    >
                                        {child.label}
                                    </Menu.Item>
                                ))}
                            </Menu.SubMenu>
                        ))}
                    </Menu>
                </Sider>

                <Content style={{ padding: 24, background: '#fff' }}>
                    <Scene3D
                        currentLevel={currentLevel}
                        setCurrentLevel={setCurrentLevel}
                        selectedItems={selectedItems}
                    />
                </Content>
            </Layout>
            <Modal
                title="档案信息"
                visible={modalVisible}
                onCancel={() => setModalVisible(false)}
                footer={null}
                
            >
                <Table dataSource={tableData} columns={tableColoum}>
                </Table>

            </Modal>
        </Layout>
    );
};

// 添加全局样式
const styles = {
    '.ant-menu-horizontal': {
        borderBottom: 'none',
    },
    '.ant-menu-horizontal > .ant-menu-item::after': {
        borderBottom: '2px solid #1890ff',
    },
    '.ant-menu-horizontal > .ant-menu-item-selected': {
        color: '#1890ff',
        borderBottom: '2px solid #1890ff',
    },
    '.ant-menu-horizontal > .ant-menu-item:hover': {
        color: '#1890ff',
        borderBottom: '2px solid #1890ff',
    }
};

// 将样式添加到 index.css

export default Main1; 