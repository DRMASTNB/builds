import {Avatar, Button, Layout, notification} from "antd";
import {ProCard} from "@ant-design/pro-components";
import React, {useEffect} from "react";
import {UserOutlined} from "@ant-design/icons";
import src from "../assets/loginBackground1.jpg";
import {useNavigate} from "react-router-dom";

const globalBackgroundImage = "url('https://mdn.alipayobjects.com/huamei_gcee1x/afts/img/A*y0ZTS6WLwvgAAAAAAAAAAAAADml6AQ/fmt.webp')";

const User = () => {
    const navigate = useNavigate();

    const userName = sessionStorage.getItem('username');
    useEffect(() => {
        console.log("login token", sessionStorage.getItem('tokenName'), sessionStorage.getItem('tokenValue'),
            "\nuser", sessionStorage.getItem('username'), sessionStorage.getItem('userRole'));
        if(userName === null) {
            navigate("/login");
        }
    }, []);
    const [notice, contextHolder] = notification.useNotification();
    const openNotification = (status, descrption) => {
        // console.log('openNotification called');
        notice['success']({
            message: status,
            description:
            descrption,
            placement: 'top',
        });
    };
    const onClickLogout = async () => {

        // 清空 sessionStorage 中的数据
        sessionStorage.removeItem('tokenName');
        sessionStorage.removeItem('tokenValue');
        sessionStorage.removeItem('username');
        sessionStorage.removeItem('userRole');
        console.log("logout token", sessionStorage.getItem('tokenName'), sessionStorage.getItem('tokenValue'),
            "\nuser", sessionStorage.getItem('username'), sessionStorage.getItem('userRole'));
        openNotification('退出成功: ', '已返回登录界面')
        navigate("/login");
    }
    return (
        <Layout
            style={{
                // background:'blue',
                minHeight: '100vh',
            }}
        >
            <ProCard
                boxShadow={true}
                style={{
                    width: "80%",
                    marginLeft: "10%",
                    marginRight: "10%",
                    height: "200px",
                    backgroundImage: `url(${src})`,
                }}

                split={"vertical"}
            >
                <ProCard style={{
                    // backgroundColor:"red",
                    marginTop: "100px",
                    height: "100px",
                    backgroundColor: "transparent",
                }}
                         colSpan="10%"
                >
                    <Avatar size={64}
                            style={{backgroundColor: '#87d068'}} icon={<UserOutlined/>}/>
                </ProCard>
                <ProCard
                    title={
                        <div
                            style={{
                                fontSize: "18px",
                            }}
                        >
                            用户昵称 : {userName}
                        </div>
                    }
                    style={{
                        // backgroundColor:"yellow",
                        height: "100px",
                        marginTop: "100px",
                        display: "flex",
                        justifyContent: "center",
                        backgroundColor: "transparent",
                    }}

                    headerBordered
                >
                    {"用户签名 : 此功能预计在下个版本上线"}
                </ProCard>
                <ProCard style={{
                    // backgroundColor:"red",
                    flexGrow: 1,
                    marginTop: "118px",
                    display: "flex",
                    justifyContent: "center",
                    backgroundColor: "transparent",
                    alignItems: "center", // 添加这行代码来实现垂直居中
                }}
                         colSpan={"10%"}
                >
                    <Button type="primary"
                            ghost
                        onClick={onClickLogout}
                    >
                        退出登录
                    </Button>
                </ProCard>
            </ProCard>
            <ProCard
                style={{
                    marginTop: "20px",
                    width: "80%",
                    marginLeft: "10%",
                    marginRight: "10%",
                    height: "100%",
                }}
                title={
                    <div
                        style={{
                            fontSize: "18px",
                        }}
                    >
                        用户信息
                    </div>
                }
                headerBordered
            >
                我现在还不知道在这里放什么东西比较好
            </ProCard>
        </Layout>
    )
};
export default User;